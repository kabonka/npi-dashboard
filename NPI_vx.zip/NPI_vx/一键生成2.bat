@echo off
setlocal EnableDelayedExpansion

REM --- proxy (same as C:\npi-dashboard) ---
git -C "%~dp0" config http.proxy http://127.0.0.1:7890 2>nul
git -C "%~dp0" config https.proxy http://127.0.0.1:7890 2>nul

REM --- run python script ---
python "%~dp0build_npi.py"
if errorlevel 1 goto end

REM --- git add ---
git -C "%~dp0" add npi_dashboard.html npi_data.json npi_search.html npi_dashboard.xlsx 2>nul

REM --- check if there is anything to commit ---
git -C "%~dp0" diff --cached --quiet 2>nul
if errorlevel 1 (
  REM has changes, commit and push
  for /f "tokens=1-3 delims=/" %%a in ("%date:/=-%") do set dd=%%a-%%b-%%c
  for /f "tokens=1-2 delims=:" %%a in ("%time::= %") do set tt=%%a%%b
  git -C "%~dp0" commit -m "Update NPI Dashboard %dd% %tt%" 2>nul
  git -C "%~dp0" push 2>nul
  if errorlevel 1 (
    echo Git push failed
  ) else (
    echo Git push OK
  )
) else (
  echo Git: nothing to commit
)

:end
pause
