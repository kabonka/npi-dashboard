@echo off
chcp 65001 >nul 2>&1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python NOT FOUND
    echo Install Python 3.7+ with "Add to PATH"
    echo https://www.python.org/downloads/
    pause
    exit /b 1
)

echo Building NPI Dashboard...
echo.
call python build_npi_1.py
if errorlevel 1 (
    echo.
    echo BUILD FAILED - See above for details
    pause
    exit /b 1
)

echo.
echo Done! Open npi_dashboard.html to view.
pause
